from setuptools import find_packages, setup

setup(
    name='utils',
    packages=find_packages(include=["utils"]),
    version='0.0.1',
    description='Basics utils functions for Python',
    author='Brixt18',
    license='MIT',
)